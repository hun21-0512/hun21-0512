package Tetris;

import java.awt.Point;
import java.awt.Font;
import java.awt.Color;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JButton;

import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;

import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.event.AncestorListener;
import javax.swing.event.AncestorEvent;


public class MyTetris{
	public static JLabel lblNewLabel = new JLabel("");
	public static JLabel lblNewLabel_1 = new JLabel("Score : 1000");
	public static JLabel lblNewLabel_2 = new JLabel("Speed : 1");
	
	public static TetrisCanvas tetrisCanvas = new TetrisCanvas();
	public static JTextArea textArea = new JTextArea();
	public static JFrame frmMytetris;
	
	/**
	 * Launch the application.
	 */
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MyTetris window = new MyTetris();
					frmMytetris.setLocation(350,150);
					
					//frmMytetris.setUndecorated(true);
					window.frmMytetris.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MyTetris() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	public void initialize() {
		
		frmMytetris = new JFrame();
		frmMytetris.setTitle("myTetris");
		frmMytetris.setBounds(100, 100, 772, 584);
		frmMytetris.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JMenuBar menuBar = new JMenuBar();
		frmMytetris.setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("1\uC778");
		menuBar.add(mnNewMenu);
		frmMytetris.getContentPane().setLayout(null);
		

		lblNewLabel.setBounds(488, 0, 270, 524);
		frmMytetris.getContentPane().add(lblNewLabel);
		tetrisCanvas.addAncestorListener(new AncestorListener() {
			public void ancestorAdded(AncestorEvent event) {
			}
			public void ancestorMoved(AncestorEvent event) {
			}
			public void ancestorRemoved(AncestorEvent event) {
			}
		});
		
		tetrisCanvas.setBounds(0, 0, 487, 524);
		
		frmMytetris.getContentPane().add(tetrisCanvas);
		tetrisCanvas.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(268, 10, 207, 111);
		tetrisCanvas.add(scrollPane);
		
		
		scrollPane.setViewportView(textArea);
		
		
		lblNewLabel_1.setFont(new Font("���� ����", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(278, 131, 174, 29);
		tetrisCanvas.add(lblNewLabel_1);
		

		lblNewLabel_2.setFont(new Font("���� ����", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(278, 164, 174, 29);
		tetrisCanvas.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel(" \uB2E4\uC74C \uBE14\uB85D");
		lblNewLabel_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_1.setFont(new Font("���� ����", Font.PLAIN, 20));
		lblNewLabel_2_1.setBounds(261, 301, 174, 29);
		tetrisCanvas.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("<html>\r\n  Q : 3x3 \uBE14\uB85D \uACF5\uACA9 <br>\r\n  (\uBE44\uC6A9 : 600) <br>\r\n<br>\r\n  W : \uB300\uAC01\uC120 \uBE14\uB85D \uACF5\uACA9<br>\r\n  (\uBE44\uC6A9 : 800)<br>\r\n<br>\r\n  E : \uC801 \uC2A4\uD53C\uB4DC 1 \uC99D\uAC00<br>\r\n  (\uBE44\uC6A9 : 500)<br>\r\n</html>");
		lblNewLabel_2_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_1_1.setBackground(Color.WHITE);
		lblNewLabel_2_1_1.setFont(new Font("���� ����", Font.PLAIN, 15));
		lblNewLabel_2_1_1.setBounds(278, 340, 174, 174);
		lblNewLabel_2_1_1.setOpaque(true);
		tetrisCanvas.add(lblNewLabel_2_1_1);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("\uC2DC\uC791");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tetrisCanvas.startGame();
				lblNewLabel_2_1_1.setVisible(false);
			}
		});
		mnNewMenu.add(mntmNewMenuItem);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("\uC885\uB8CC");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tetrisCanvas.stopGame();
			}
		});
		mnNewMenu.add(mntmNewMenuItem_1);
		
		JMenu mnNewMenu_1 = new JMenu("\uC628\uB77C\uC778");
		menuBar.add(mnNewMenu_1);
		
		JMenuItem mntmNewMenuItem_2 = new JMenuItem("\uBC29 \uB9CC\uB4E4\uAE30");
		mntmNewMenuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				String input = JOptionPane.showInputDialog("��Ʈ�� �Է��ϼ���");
				tetrisCanvas.OpenServer(Integer.parseInt(input));
				
			}
		});
		mnNewMenu_1.add(mntmNewMenuItem_2);
		
		JMenuItem mntmNewMenuItem_3 = new JMenuItem("\uBC29 \uC785\uC7A5\uD558\uAE30");
		mntmNewMenuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String ip = JOptionPane.showInputDialog("���� �ּҸ� �Է��ϼ���");
				String input = JOptionPane.showInputDialog("��Ʈ�� �Է��ϼ���");
				tetrisCanvas.EnterServer(Integer.parseInt(input),ip);			
			}
		});
		mnNewMenu_1.add(mntmNewMenuItem_3);
		
		JMenuItem mntmNewMenuItem_4 = new JMenuItem("\uC2DC\uC791");
		mntmNewMenuItem_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tetrisCanvas.OnlineStart();
			}
		});
		mnNewMenu_1.add(mntmNewMenuItem_4);
		
		JMenuItem mntmNewMenuItem_5 = new JMenuItem("\uC2A4\uD53C\uB4DC\uC804 \uC2DC\uC791");
		mntmNewMenuItem_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tetrisCanvas.OnlineSpeedStart();
			}
		});
		mnNewMenu_1.add(mntmNewMenuItem_5);
		
		JMenu mnNewMenu_2 = new JMenu("\uAC1C\uBC1C\uC790 \uC815\uBCF4");
		menuBar.add(mnNewMenu_2);
		
		JMenuItem mntmNewMenuItem_6 = new JMenuItem("\uAC1C\uBC1C\uC790 \uC815\uBCF4");
		mntmNewMenuItem_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String rly;
				rly = JOptionPane.showInputDialog("203631 ������\n203620 �ŵ���\n\n�޽����� �Է��ϼ���");
				if (rly.contains("�ȳ�")) {
					JOptionPane.showMessageDialog(null, "�ȳ��ϼ���");
				}
				else if (rly.contains("���")) {
					JOptionPane.showMessageDialog(null, "��ſ� �ð��Ǽ���");
				}
				else if (rly.contains("203620")||rly.contains("�ŵ���")||rly.contains("203631")||rly.contains("������")){
					JOptionPane.showMessageDialog(null, "��Ʈ���� �������Դϴ�");
				}
				else if (rly.contains("���¹�")) {
					JOptionPane.showMessageDialog(null, "�����Դϴ�");
				}
				else if (rly.contains("J��")||rly.contains("����")) {
					JOptionPane.showMessageDialog(null, "203631������\n203620�ŵ���\n2036**���¹�");
				}
				else if (rly.contains("����")) {
					System.exit(0);
				}
				else {
					JOptionPane.showMessageDialog(null, "�𸣰ڽ��ϴ�");
				}
				
			}
		});
		mnNewMenu_2.add(mntmNewMenuItem_6);
	}
}
