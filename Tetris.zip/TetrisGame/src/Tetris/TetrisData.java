package Tetris;

public class TetrisData {
    public static final int ROW = 20;
    public static final int COL = 10;

    private int data[][]; // ROW x COL �� �迭
    private int line; // ���� �� ��

    public TetrisData() {
        data = new int[ROW][COL];
    }
    
    //x, y�� ������ �ִ��� Ȯ��
    public int getAt(int x, int y) {
        if (x < 0 || x >= ROW || y < 0 || y >= COL)
            return 0;
        return data[x][y];
    }
    
    //
    public void setAt(int x, int y, int v) {
        data[x][y] = v;
    }

    //���� �� �� �Լ�
    public int getLine() {
        return line;
    }

    public synchronized void removeLines() {
        NEXT: for (int i = ROW - 1; i >= 0; i--) {
            // �οﺯ�� done ���� true
        	boolean done = true;
        	
        	//
            for (int k = 0; k < COL; k++) {
                if (data[i][k] == 0) {
                    done = false;
                    continue NEXT;
                }
            }
            
            //
            if (done) {
                line++;
                if(MyTetris.tetrisCanvas.isOnline) {
                	MyTetris.tetrisCanvas.Score += 200;
                }

                if(line%5==0 && !MyTetris.tetrisCanvas.isOnline) {
                	MyTetris.tetrisCanvas.level+=1;
                }
                if(line%5==0 && MyTetris.tetrisCanvas.isOnline&&MyTetris.tetrisCanvas.isSpeed) {
                	MyTetris.tetrisCanvas.SpeedATK();
                }
                for (int x = i; x > 0; x--) {
                    for (int y = 0; y < COL; y++) {
                        data[x][y] = data[x - 1][y];
                    }
                }

                if (i != 0) {
                    for (int y = 0; y < COL; y++) {
                        data[0][y] = 0;
                    }
                }
            }
        }
    }

    public void clear() { // data �迭 �ʱ�ȭ
        for (int i = 0; i < ROW; i++) {
            for (int k = 0; k < COL; k++) {
                data[i][k] = 0;
            }
        }
    }

    public void dump() { // data �迭 ���� ���
        for (int i = 0; i < ROW; i++) {
            for (int k = 0; k < COL; k++) {
                System.out.print(data[i][k] + " ");
            }
            System.out.println();
        }
    }
}
