package Tetris;

public class Cube extends Piece {
	
	public Cube(TetrisData data) {
        super(data);     
        c[0] = 0;        r[0] = 0;
        c[1] = 1;        r[1] = 0;
        c[2] = 0;        r[2] = 1;
        c[3] = 1;        r[3] = 1;
        c[4] = -1;       r[4] = -1;
        c[5] = -1;       r[5] = 0;
        c[6] = 0;        r[6] = -1;
        c[7] = -1;       r[7] = 1;
        c[8] = 1;        r[8] = -1;

    }

    public int getType() {
        return 8;
    }

    public int roteType() {
        return 1;
    }
}
