package Tetris;

import java.awt.*;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Calendar;

public class TetrisCanvas extends JPanel 
	implements Runnable, KeyListener {
    protected Thread worker;
    protected Color colors[];
    protected TetrisData data;
    protected Piece current;
    protected Piece next;
    
    protected int w = 25;
    protected int margin = 20;
    protected int interval = 2000;
    
    public int level = 2;
    public int Port;
    public int Score, random;
    
    private DatagramSocket Datasock;
    public Socket sock;
    public InetAddress  address;
    public String myip;
    public String yourip;
    
    protected boolean stop, makeNew;
    public boolean isFull;
    public boolean isOnline, isServer, isClient, isSpeed;
    
    
    public TetrisCanvas() {
        data = new TetrisData();
        try {
			address = InetAddress.getLocalHost();
			myip = address.getHostAddress();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
        

        addKeyListener(this);
        colors = new Color[10]; // ��Ʈ���� ��� �� ���� ��
        colors[0] = new Color(80, 80, 80); // ����(����ȸ��)
        colors[1] = new Color(255, 0, 0); //������
        colors[2] = new Color(0, 255, 0); //���
        colors[3] = new Color(0, 200, 255); //�����
        colors[4] = new Color(255, 255, 0); //�ϴû�
        colors[5] = new Color(255, 150, 0); //Ȳ���
        colors[6] = new Color(210, 0, 240); //�����
        colors[7] = new Color(40, 0, 240); //�Ķ���
        colors[8] = new Color(50, 50, 50); //������
        colors[9] = new Color(255, 51, 153); //��ȫ��
    }

    public void startGame() { // ���� ���� 
    	stop = true;
        current = null;
    	Score = 0;
    	level = 2;
        data.clear();
        worker = new Thread(this);
        worker.start();
        makeNew = true;
        stop = false;
        requestFocus();
        repaint();
        
       
    }

    public void stopGame() {
        stop = true;
        current = null;
        isSpeed = false;
    }

    public void paint(Graphics g) {
        super.paint(g);

        for (int i = 0; i < TetrisData.ROW; i++) { //���� ������ �׸���
            for (int k = 0; k < TetrisData.COL; k++) {
                if (data.getAt(i, k) == 0) {
                    g.setColor(colors[data.getAt(i, k)]);
                    g.draw3DRect(margin / 2 + w * k,
                        margin / 2 + w * i, w, w, true);
                } else {
                    g.setColor(colors[data.getAt(i, k)]);
                    g.fill3DRect(margin / 2 + w * k,
                        margin / 2 + w * i, w, w, true);
                }
            }
        }
        
        for (int i = 0; i < 4; i++) { 
            for (int k = 0; k < 4; k++) {
                if (data.getAt(i, k) == 0) {
                    g.setColor(colors[data.getAt(i, k)]);
                    g.draw3DRect(300 + w * k,
                    		200  + w * i, w, w, true);
                } else {
                    g.setColor(colors[data.getAt(i, k)]);
                    g.fill3DRect(300  + w * k,
                    		200  + w * i, w, w, true);
                }
            }
        }
        if (next != null) { 
            for (int i = 0; i < 9; i++) {
                g.setColor(colors[next.getType()]);
                g.fill3DRect(300 +
                    w * (1+ next.c[i]),
                    200 + w * (1+ next.r[i]),
                    w, w, true);
            }
        }
        

        if (current != null) { // ���� �������� �ִ� ��Ʈ���� ���� �׸���
            for (int i = 0; i < 9; i++) {
                g.setColor(colors[current.getType()]);
                g.fill3DRect(margin / 2 +
                    w * (current.getX() + current.c[i]),
                    margin / 2 + w * (current.getY() + current.r[i]),
                    w, w, true);
            }
        }
        
        
    }
    public Dimension getPreferredSize() { // ��Ʈ���� ���� ũ�� ����
        int tw = w * TetrisData.COL + margin;
        int th = w * TetrisData.ROW + margin;
        return new Dimension(tw, th);
    }

    public void run() {
    	 if(isOnline) {
            	Receive();
            	Send();
            }
    	random = (int)
                (Math.random() * Integer.MAX_VALUE) % 7;
        while (!stop) {
        	if(isOnline) {
        		MyTetris.lblNewLabel_1.setText("Score : "+ Score);
        		
        	}else {
        		MyTetris.lblNewLabel_1.setText("Score : "+ data.getLine() * 175 * level);
        	}
        	MyTetris.lblNewLabel_2.setText("Speed : "+  (level-1));
            try {
                if (makeNew) { // ���ο� ��Ʈ���� ���� �����
                	  
                    switch (random) {
                        case 0:
                            current = new Bar(data);
                            break;
                        case 1:
                            current = new Tee(data);
                            break;
                        case 2:
                            current = new El(data);
                            break;
                        case 3:
                        	current = new Rl(data);
                        	break;
                        case 4:
                        	current = new Square(data);
                        	break;
                        case 5:
                        	current = new RZ(data);
                        	break;
                        case 6:
                        	current = new LZ(data);
                        	break;
                        case 7:
                        	current = new Cube(data);
                        	break;
                        case 8:
                        	current = new Cross(data);
                        	break;
                        default:
                            if (random % 2 == 0)
                                current = new Tee(data);
                            else current = new El(data);
                    }
                    random = (int)
                            (Math.random() * Integer.MAX_VALUE) % 7;
                    switch (random) {
                    case 0:
                        next = new Bar(data);
                        break;
                    case 1:
                        next = new Tee(data);
                        break;
                    case 2:
                    	next = new El(data);
                        break;
                    case 3:
                    	next = new Rl(data);
                    	break;
                    case 4:
                    	next = new Square(data);
                    	break;
                    case 5:
                    	next = new RZ(data);
                    	break;
                    case 6:
                    	next = new LZ(data);
                    	break;
                    case 7:
                    	next = new Cube(data);
                    	break;
                    case 8:
                    	next = new Cross(data);
                    	break;
                    default:
                        if (random % 2 == 0)
                        	next = new Tee(data);
                        else next = new El(data);
                }
                    makeNew = false;
                } else { // ���� ������� ��Ʈ���� ���� �Ʒ��� �̵�
                    if (current.moveDown()) {
                        makeNew = true;
                        if (current.copy()) {
                            stopGame();
                            if(!isOnline) {               
                                int score = data.getLine() * 175 * level;
                                JOptionPane.showMessageDialog(this, "���ӳ�\n���� : " + score);
                                }else {
                                	PrintWriter pw = new PrintWriter(sock.getOutputStream(), true);
                            		pw.println("Win");	
                        	        stopGame();
                        	        JOptionPane.showMessageDialog(this, "�й�");
                                }
                            
                        }
                        current = null;
                    }
                    data.removeLines();
                    
                }
                repaint();
             
                Thread.currentThread().sleep(interval / level);
            } catch (Exception e) {}
        }
    }

    // Ű���带 �̿��ؼ� ��Ʈ���� ���� ����
    
    
    public void OpenServer(int port) {
		try {
			ServerSocket ssk = new ServerSocket(port);
			Port = port;
			isServer =true;
			System.out.print("������ ����� ip: "+ myip);
			MyTetris.textArea.append("������ ����� \n ip: "+ myip +"\n port: "+ port);
			isOnline =true;
			Thread th = new Thread() {
       		 public void run() {
       			while(true) {   		        
	       			 try {
	       				 sock = ssk.accept(); // ���ο� ������ ���� Ŭ���̾�Ʈ�� �������� , ����������  ����Ǵ� ����
	       				 //byte outbuff[] = new byte[80000];
	       				 System.out.println("����� ���� �߽��ϴ�");
	    		         System.out.println("Client ip :"+ sock.getInetAddress());
	    		         MyTetris.textArea.append("\n����� ���� �߽��ϴ�");
	    		         MyTetris.textArea.append("\nClient ip :"+ sock.getInetAddress());
	    		         yourip = sock.getInetAddress().getHostAddress();
	    		         System.out.println(yourip);
		    		     isFull = true;

    					
    			        
	       			 } catch(Exception e) {
	       				 e.printStackTrace();
	       			 }
       			}
       			
       		 }
        };
         th.start();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
    }
    
    
    
    public void EnterServer(int port, String ip) {
    	try {
    		sock = new Socket(ip,port);
    		Port = port;
    		yourip = ip;
    		isOnline =true;
    		isClient =true;
    		System.out.println("\n���� ���� ����!");
    		MyTetris.textArea.append("���� ���� ����!");
    		Thread th = new Thread() {
    			public void run() {
    				try {
    					while(true) {
    						BufferedReader br = new BufferedReader(
									new InputStreamReader (sock.getInputStream()));
							String msg = br.readLine();
        			        	if(msg.equals("start")) {
            			        	startGame(); 
            			        }
        			        	if(msg.equals("Speedstart")) {
            			        	startGame(); 
            			        	isSpeed= true;
            			        }
        			        	if(msg.equals("Win")) {
    					        	stopGame(); 
    					        	JOptionPane.showMessageDialog( null,"�¸�");
    					        }
    					        if(msg.equals("ATK1")) {
    					        	 random = 7;
    					        	 next = new Cube(data);
    					        }
    					        if(msg.equals("ATK2")) {
    					        	random = 8;
    					        }
    					        if(msg.equals("ATK3")) {
    					        	level+=1;
    					        }
        			       
        			        
        				}
					} catch (Exception e) {
						// TODO: handle exception
					}
    			}
    		};
    		th.start();
 

		} catch (Exception e) {
			System.out.println("���� : ���ӽ���");
		}
    }
    public void Send() {
    	Thread th = new Thread() {
    		public void run() {
    			try {
        			byte outbuff[] = new byte[80000];
        			while(!stop) {
        				Robot robot = new Robot();
        				//System.out.println("�̹���������");
	    				Rectangle area = new Rectangle(MyTetris.frmMytetris.getLocation().x+10,MyTetris.frmMytetris.getLocation().y+55 , 270, 520);
	    				BufferedImage bufferedImage = robot.createScreenCapture(area);
					    ImageIcon imc = new ImageIcon(bufferedImage);
					    
					    ByteArrayOutputStream baos = new ByteArrayOutputStream();
					    ImageIO.write(bufferedImage, "jpg", baos);
					    address = InetAddress.getByName(yourip);
					    outbuff = baos.toByteArray();
					    if(isServer&&!isClient) {
					    	DatagramPacket dp = new DatagramPacket(outbuff, outbuff.length, address, 7000);
					    	Datasock.send(dp);
					    }
					    else if(!isServer&&isClient) {
					    	DatagramPacket dp = new DatagramPacket(outbuff, outbuff.length, address, 8000);
					    	Datasock.send(dp);
					    }
					    Thread.currentThread().sleep(2000);
        			}
				} catch (Exception e) {
					 System.out.println("�̹��� ���� ���� �߻�");
					   e.printStackTrace();
				}

    		}
    		
    	};
    	try {
			
		} catch (Exception e) {
			// TODO: handle exception
		}
    	
    	th.start();
    }
    public void Receive() {
    	Thread th = new Thread() {
    		public void run() {
    			try {
    				byte[] rcvbyte = new byte[80000];
	 	 			DatagramPacket dp = new DatagramPacket(rcvbyte, rcvbyte.length);
		 			BufferedImage bf;
		 			ImageIcon imc;
		 			address = InetAddress.getByName(myip);
		 			if(isServer&&!isClient) {
		 				Datasock = new DatagramSocket(8000);
				    }
		 			else if(!isServer&&isClient){
		 				Datasock = new DatagramSocket(7000);
		 			}
		 			
		 			while(!stop) {
		 				//System.out.println("�̹��� ������");
				 		Datasock.receive(dp);
				 		ByteArrayInputStream bais = new ByteArrayInputStream(rcvbyte);
				 		bf = ImageIO.read(bais); 		
				 		if(bf != null) {
				 			imc = new ImageIcon(bf);
				 			MyTetris.lblNewLabel.setIcon(imc);
				 			Thread.sleep(15);
				 			}
				 		Thread.currentThread().sleep(2000);
		 			}
		 			
		 			//sock = new DatagramSocket(portNum);
				} catch (Exception e) {
					e.printStackTrace();
		 			System.out.println("�̹��� ���� ���� �߻�");
				}
    		}
    	};
    	 th.start();
    }

    public void keyPressed(KeyEvent e) {
        if (current == null) return;

        switch (e.getKeyCode()) {
        	case 81://Q
        		if(isOnline&&!isSpeed) {
        			if(Score >=600) {
        				Score -= 600;
        				try {
        					PrintWriter pw = new PrintWriter(sock.getOutputStream(), true);
        		    		pw.println("ATK1");	
						} catch (Exception e2) {

						}
        			}
        		}else {
        			random = 7;
		        	 next = new Cube(data);
        		}
        		break;
        	case 87:
        		if(isOnline&&!isSpeed) {
        			if(Score >=800) {
        				Score -= 800;
        				try {
        					PrintWriter pw = new PrintWriter(sock.getOutputStream(), true);
        		    		pw.println("ATK2");	
						} catch (Exception e2) {

						}
        			}
        		}else {
        			random = 8;
		        	 next = new Cross(data);
        		}
        		break;
        	case 69:
        		if(isOnline&&!isSpeed) {
        			if(Score >=500) {
        				Score -= 500;
        				try {
        					PrintWriter pw = new PrintWriter(sock.getOutputStream(), true);
        		    		pw.println("ATK3");	
						} catch (Exception e2) {

						}
        			}
        		}else {
        			level+=1;
        		}
        		break;
            case 37: // ���� ȭ��ǥ
                current.moveLeft();
                repaint();
                break;
            case 39: // ������ ȭ��ǥ
                current.moveRight();
                repaint();
                break;
            case 38: // ���� ȭ��ǥ
                current.rotate();
                repaint();
                break;
            case 40: // �Ʒ��� ȭ��ǥ
                boolean temp = current.moveDown();
                if (temp) {
                    makeNew = true;
                    if (current.copy()) {
                        stopGame();           
                        if(!isOnline) {               
                        int score = data.getLine() * 175 * level;
                        JOptionPane.showMessageDialog(this, "���ӳ�\n���� : " + score);
                        }else {
                        	try {
                        		PrintWriter pw = new PrintWriter(sock.getOutputStream(), true);
                        		pw.println("Win");	
                    	        stopGame();
                    	        JOptionPane.showMessageDialog(this, "�й�");
							} catch (Exception e2) {
								// TODO: handle exception
							}
                        	
                        }
                        
                    }
                    data.removeLines();
                }
                repaint();
                break;
        }
    }
    public void OnlineStart() {
    	try {
    		PrintWriter pw = new PrintWriter(sock.getOutputStream(), true);
    		pw.println("start");	
	        startGame();
	        Thread th = new Thread() {
	        	public void run() {
	        		try {
	        			 while(true) {
	        				 BufferedReader br = new BufferedReader(
										new InputStreamReader (sock.getInputStream()));
								String msg = br.readLine();
	        			        	if(msg.equals("Win")) {
	        			        		
	    					        	stopGame(); 
	    					        	JOptionPane.showMessageDialog( null,"�¸�");
	    					        	
	    					        }
	    					        if(msg.equals("ATK1")) {
	    					        	 random = 7;
	    					        	 next = new Cube(data);
	    					        }
	    					        if(msg.equals("ATK2")) {
	    					        	random = 8;
	    					        }
	    					        if(msg.equals("ATK3")) {
	    					        	level+=1;
	    					        }
	        				        
	        		        }
	        		}
					 catch (Exception e) {
						// TODO: handle exception
					}
	       
	        }
	        };
	        th.start();
		} catch (Exception e) {
			// TODO: handle exception
		}
    	 	
     
    }
    public void SpeedATK() {
    	try {
			PrintWriter pw = new PrintWriter(sock.getOutputStream(), true);
    		pw.println("ATK3");	
		} catch (Exception e2) {

		}
    }
    public void OnlineSpeedStart() {
    	try {
    		PrintWriter pw = new PrintWriter(sock.getOutputStream(), true);
    		pw.println("Speedstart");	
    		isSpeed = true;
	        startGame();
	        Thread th = new Thread() {
	        	public void run() {
	        		try {
	        			 while(true) {
	        				 BufferedReader br = new BufferedReader(
										new InputStreamReader (sock.getInputStream()));
								String msg = br.readLine();
	        			        	if(msg.equals("Win")) {
	        			        		
	    					        	stopGame(); 
	    					        	JOptionPane.showMessageDialog( null,"�¸�");
	    					        	
	    					        }
	    					        if(msg.equals("ATK1")) {
	    					        	 random = 7;
	    					        	 next = new Cube(data);
	    					        }
	    					        if(msg.equals("ATK2")) {
	    					        	random = 8;
	    					        }
	    					        if(msg.equals("ATK3")) {
	    					        	level+=1;
	    					        }
	        				        
	        		        }
	        		}
					 catch (Exception e) {
						// TODO: handle exception
					}
	       
	        }
	        };
	        th.start();
		} catch (Exception e) {
			// TODO: handle exception
		}
    	 	
     
    }
    
    public void keyReleased(KeyEvent e) {}
    public void keyTyped(KeyEvent e) {}

}
